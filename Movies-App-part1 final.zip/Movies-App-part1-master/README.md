# Movies-App-part1
that is movies app stage 1
that preview (top rated or most popular ) movies

NOTE
don't forget to
add your API key
