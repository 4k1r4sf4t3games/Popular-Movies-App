package com.udacity.moviesapp.ui;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.udacity.moviesapp.R;
import com.udacity.moviesapp.databinding.ActivityMainBinding;
import com.udacity.moviesapp.ui.MainFragment;
import com.udacity.moviesapp.utils.JsonUtils;
import com.udacity.moviesapp.utils.NetworkUtils;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Declare Data Binding
    ActivityMainBinding mMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initial Data Binding
        mMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);


        //Add fragment to frame layout

        getSupportFragmentManager().beginTransaction()
                .replace(mMainBinding.frameLayout.getId(), new MainFragment())
                .commit();


    }


}
