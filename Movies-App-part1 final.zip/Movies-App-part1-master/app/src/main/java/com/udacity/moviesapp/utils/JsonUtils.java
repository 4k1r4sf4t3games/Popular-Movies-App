package com.udacity.moviesapp.utils;

import com.udacity.moviesapp.models.Movie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class JsonUtils {


    private static String PosterUri = "https://image.tmdb.org/t/p/w500/";
    private static String RESULTS = "results";
    private static String TITLE = "title";
    private static String RELEASE_DATA = "release_date";
    private static String OVERVIEW = "overview";
    private static String VOTE_AVERAGE = "vote_average";
    private static String THUMBNAIL_PATH = "backdrop_path";
    private static String POSTER_PATH = "poster_path";


    //get all movies data
    public static ArrayList<String> getMoviesData(String json) {

        try {
            JSONObject object = new JSONObject(json);
            JSONArray results = object.getJSONArray(RESULTS);
            ArrayList<String> moviesData = new ArrayList<>();

            for (int i = 0; i < results.length(); i++) {
                moviesData.add(results.optString(i));
            }

            return moviesData;


        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }


    }


    //get all movies posters
    public static ArrayList<String> posters(String json) {
        try {
            JSONObject object = new JSONObject(json);
            JSONArray results = object.getJSONArray(RESULTS);
            ArrayList<String> imagePosters = new ArrayList<>();

            for (int i = 0; i < results.length(); i++) {
                JSONObject data = results.getJSONObject(i);

                imagePosters.add(PosterUri + data.optString(POSTER_PATH));

            }


            return imagePosters;


        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

    }

    //get specific movie data
    public static Movie getMovieDetail(String json) {
        Movie movie = null;
        try {

            JSONObject object = new JSONObject(json);
            String title = object.optString(TITLE);
            String releaseData = object.optString(RELEASE_DATA);
            String overview = object.optString(OVERVIEW);
            String thumbnails = PosterUri + object.optString(THUMBNAIL_PATH);

            float voteAverage = (float) object.optDouble(VOTE_AVERAGE);

            movie = new Movie(title, releaseData, overview, thumbnails, voteAverage);

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return movie;
    }


}
