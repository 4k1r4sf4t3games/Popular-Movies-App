package com.udacity.moviesapp.ui;


import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.udacity.moviesapp.R;
import com.udacity.moviesapp.databinding.FragmentDetailsBinding;
import com.udacity.moviesapp.models.Movie;
import com.udacity.moviesapp.utils.JsonUtils;


public class DetailsFragment extends Fragment {


    //Declare Data Binding variable
    FragmentDetailsBinding mDetailsBinding;


    public DetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Initial Data Binding variable
        mDetailsBinding = DataBindingUtil.inflate(inflater,
                R.layout.fragment_details,
                container, false);


        //check on arguments
        Bundle bundle = this.getArguments();
        if (bundle == null) {
            closeOnError();

        } else {
            //get json from arguments
            String json = bundle.getString(getString(R.string.key));

            //parse movie json
            Movie movie = JsonUtils.getMovieDetail(json);
            //preview image
            Picasso
                    .with(getContext())
                    .load(movie.getThumbnails())
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.error)
                    .into(mDetailsBinding.imageView);

            //populate data to UI
            populateUI(movie);

        }


        return mDetailsBinding.getRoot();
    }


    private void closeOnError() {
        Toast.makeText(getContext(), getString(R.string.detail_error_message), Toast.LENGTH_SHORT).show();
        getFragmentManager().popBackStack();
    }

    void populateUI(Movie movie) {
        mDetailsBinding.tvTitle.setText(movie.getTitle());
        mDetailsBinding.tvReleaseData.setText(movie.getRelease_data());
        mDetailsBinding.tvUserRate.setText(String.valueOf(movie.getVote_average()));
        mDetailsBinding.tvOverview.setText(movie.getOverview());
    }

}
