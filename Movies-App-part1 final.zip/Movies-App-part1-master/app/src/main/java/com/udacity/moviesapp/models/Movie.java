package com.udacity.moviesapp.models;


public class Movie {


    private String title, release_data, overview, thumbnails;
    private float vote_average;


    public Movie(String title, String release_data, String overview, String thumbnails, float vote_average) {
        this.title = title;
        this.release_data = release_data;
        this.overview = overview;
        this.thumbnails = thumbnails;
        this.vote_average = vote_average;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRelease_data() {
        return release_data;
    }

    public void setRelease_data(String release_data) {
        this.release_data = release_data;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getThumbnails() {
        return thumbnails;
    }

    public void setThumbnails(String thumbnails) {
        this.thumbnails = thumbnails;
    }

    public float getVote_average() {
        return vote_average;
    }

    public void setVote_average(float vote_average) {
        this.vote_average = vote_average;
    }
}
