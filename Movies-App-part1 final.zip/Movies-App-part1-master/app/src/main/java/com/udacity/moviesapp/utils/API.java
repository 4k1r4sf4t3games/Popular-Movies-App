package com.udacity.moviesapp.utils;


public class API {

    //TODO Add Your API
    private static String API_KEY = "7e3aaba6800c00a1d9033f39ad1a2bc3";

    public static String getAPIKey() {
        return API_KEY;
    }
}
