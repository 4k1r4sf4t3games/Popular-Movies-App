package com.udacity.moviesapp.ui;


import android.annotation.SuppressLint;
import android.databinding.DataBindingUtil;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Toast;

import com.udacity.moviesapp.R;
import com.udacity.moviesapp.data.ImageAdapter;
import com.udacity.moviesapp.databinding.FragmentMainBinding;
import com.udacity.moviesapp.utils.ConnectionUtils;
import com.udacity.moviesapp.utils.JsonUtils;
import com.udacity.moviesapp.utils.NetworkUtils;

import java.util.ArrayList;


public class MainFragment extends Fragment {


    //Declare DAta Binding Variable
    private FragmentMainBinding mFragmentMainBinding;
    /*
     * declare int variable
     * to check between two states (most popular , top rated)
     * to prevent loading exist data
     * */

    //initial integer state variable
    private int mCurrentState;


    //two Strings for state
    private static final String popular = "popular";
    private static final String top_rated = "top_rated";
    /*
     * store movies data
     * that will pass to detail fragment
     * */
    private ArrayList<String> moviesData;

    public MainFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //initial data binding variable
        mFragmentMainBinding =
                DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false);

        //initial movies data array list
        moviesData = new ArrayList<>();


        mCurrentState = 0;
        //enable option menu from fragment
        setHasOptionsMenu(true);
        /*
         * set toolbar title method
         * default sort is Most Popular
         * */
        setToolbarTitle(getString(R.string.most_popular));

        //Check On Connection
        if (ConnectionUtils.checkConnection(getContext())) {
            new ImageTask().execute(popular);
            mFragmentMainBinding.moviesGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    if (moviesData != null) {


                        /*Create Fragment
                         * and pass movie data through it*/
                        DetailsFragment detailsFragment = new DetailsFragment();
                        Bundle bundle = new Bundle();
                        bundle.putString(getString(R.string.key), moviesData.get(i));
                        detailsFragment.setArguments(bundle);


                        getActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.frame_layout, detailsFragment)
                                .addToBackStack(null)
                                .commit();
                    }
                }
            });
        } else {
            Toast.makeText(getContext(), getString(R.string.check_internet_connection), Toast.LENGTH_LONG).show();
        }

        return mFragmentMainBinding.getRoot();
    }


    private void setToolbarTitle(String Title) {
        /*
         * this method take string parameter
         * and then put it as toolbar title
         * */
        if (((AppCompatActivity) getActivity()).getSupportActionBar() != null) {

            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(Title);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        getActivity().getMenuInflater().inflate(R.menu.main_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //check on most popular state
        if (item.getItemId() == R.id.most_popular_action && mCurrentState != 0) {

            //change state
            mCurrentState = 0;

            //set toolbar title
            setToolbarTitle(getString(R.string.most_popular));

            //make new task with this new sort
            new ImageTask().execute(popular);
        }
        //check on top rated state
        else if (item.getItemId() == R.id.top_rated_action && mCurrentState == 0) {

            //change state
            mCurrentState = 1;

            //set toolbar title
            setToolbarTitle(getString(R.string.top_rated));

            //make new task with this new sort
            new ImageTask().execute(top_rated);
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("StaticFieldLeak")
    public class ImageTask extends AsyncTask<String, Void, ArrayList<String>> {

        @Override
        protected void onPreExecute() {

            mFragmentMainBinding.progressBar.setVisibility(View.VISIBLE);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<String> posters) {
            /*
             * Hide progressbar
             * and add posters array list to image adapter
             * to preview it
             * */
            mFragmentMainBinding.progressBar.setVisibility(View.INVISIBLE);
            if (posters != null) {
                ImageAdapter adapter = new ImageAdapter(getContext(), posters);
                mFragmentMainBinding.moviesGrid.setAdapter(adapter);
            }

            super.onPostExecute(posters);
        }

        @Override
        protected ArrayList<String> doInBackground(String... strings) {
            String sort = strings[0];


            //retrieve movies data from url

            moviesData = JsonUtils.getMoviesData(NetworkUtils.getResponseFromHttpUrl(NetworkUtils.buildUrl(sort)));

            //retrieve json movie posters
            String response = NetworkUtils.getResponseFromHttpUrl(NetworkUtils.buildUrl(sort));
            //parse json movie posters
            return JsonUtils.posters(response);
        }
    }

}
