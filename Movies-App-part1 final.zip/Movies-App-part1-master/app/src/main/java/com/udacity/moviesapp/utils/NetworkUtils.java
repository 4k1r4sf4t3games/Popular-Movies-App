package com.udacity.moviesapp.utils;

import android.net.Uri;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class NetworkUtils {

    private static final String STATIC_MOVIES_URI = "http://api.themoviedb.org/3/movie/";
    private static final String API_KEY = "api_key";


    /*
     * build uri
     * with api key
     * and
     * sort type
     * */
    public static URL buildUrl(String Sort) {
        Uri movieUri = Uri.parse(STATIC_MOVIES_URI).buildUpon()
                .appendPath(Sort)
                .appendQueryParameter(API_KEY, API.getAPIKey())
                .build();

        try {
            return new URL(movieUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;

        }


    }

    /*
     * retrieve data response
     * from building
     * to parse it
     * */
    public static String getResponseFromHttpUrl(URL url) {
        HttpURLConnection urlConnection = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            InputStreamReader inputStream = new InputStreamReader(urlConnection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(inputStream);

            return bufferedReader.readLine();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return null;
    }

}
